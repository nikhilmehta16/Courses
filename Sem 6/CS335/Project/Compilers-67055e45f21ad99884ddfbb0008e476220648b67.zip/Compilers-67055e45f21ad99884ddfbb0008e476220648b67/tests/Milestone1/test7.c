// This is for error testing

int main() {
    int #k = 1;
    #k++;
    #k--;
    return 0;
}