lex.py can be run using: 
    python3 lex.py <file_path>

parser.py can be run using:
    python3 parser.py <file_path>