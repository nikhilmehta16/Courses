#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <errno.h>
#include<unistd.h> 
#include <sys/stat.h>
#include<fcntl.h>

size_t MAX_FILE_SIZE = 1000000000;


int main(int argc, char *argv[])
{

	if(strcmp(argv[1],"-c")==0) {
		if(argc!=4){
			printf("Failed to complete creation operation");
			exit(-1);
		}

		struct dirent *de;
		int total_files = 0;
		unsigned long long int total_size = 0,file_size = 0;
		struct stat st;
		char *buf = (char *) malloc(MAX_FILE_SIZE);

		DIR *dirp = opendir(argv[2]);
		errno = 0;

		if(dirp==NULL || chdir(argv[2])==-1) {
			printf("Failed to complete creation operation");
			exit(-1);
		}


		int tarfp = open(argv[3], O_RDWR | O_CREAT, 0644);
		
		if(tarfp<1){
			printf("Failed to complete creation operation");
			exit(-1);
		}
		
		write(tarfp,&total_size,sizeof(long long int));
		write(tarfp,&total_files,sizeof(int));
		
		
		char buf2[256];
		while ((de = readdir(dirp)) != NULL){
			if(strcmp(de->d_name,".")==0 || strcmp(de->d_name,"..")==0 || strcmp(de->d_name,argv[3])==0) continue;

			if(stat(de->d_name,&st)==-1){
				printf("Failed to complete creation operation");
				return 0;
			}
			total_files++;
			int fp = open(de->d_name,O_RDONLY);
			if(fp<1){
				printf("Failed to complete creation operation");
				exit(-1);
			}

			sprintf(buf2,"%s",de->d_name);
			write(tarfp,buf2,100);
			file_size = (long long)st.st_size;
			write(tarfp,&file_size, sizeof(long long int));
			total_size+=file_size;
			read(fp,buf,st.st_size);
			write(tarfp,buf,st.st_size);
			close(fp);
		}
		lseek(tarfp,0,SEEK_SET);
		write(tarfp,&total_size,sizeof(long long int));
		write(tarfp,&total_files,sizeof(int));
		free(buf);

		closedir(dirp);
		close(tarfp); //EH
		if(errno!=0) {
			printf("Failed to complete creation operation");
			exit(-1);
		}
		

	}else if(strcmp(argv[1],"-d")==0){
		if(argc!=3) {
			printf("Failed to complete extraction operation");
			exit(-1);
		}

		int fp = open(argv[2],O_RDONLY),fp1;

		if(fp==-1) {
			printf("Failed to complete extraction operation");
			exit(-1);
		}

		for(int i = 0;i<strlen(argv[2]);i++){
			if(argv[2][strlen(argv[2])-1-i]=='.') {
				argv[2][strlen(argv[2])-1-i] = '\0';
				break;
			}
		}

		char* path = malloc(strlen(argv[2])+10);
		sprintf(path,"%sDump",argv[2]);
		
		if (mkdir(path,0777)==-1){
			printf("Failed to complete extraction operation");
			exit(-1);
		}
		if (chdir(path)==-1){
			printf("Failed to complete extraction operation");
			exit(-1);
		}
		unsigned long long int file_size = 0;
		int total_files = 0,a;
		char *file_name = malloc(sizeof(char)*100);
		char *file_buf;
		a = read(fp,&file_size,sizeof(long long int));
		a = read(fp,&total_files,sizeof(int));
		a = read(fp,file_name,100);

		while(a!=0){
			
			fp1 = open(file_name,O_RDWR | O_CREAT,0644);

			if(fp1<0) {
				printf("Failed to complete extraction operation");
				exit(-1);
			}

			a = read(fp,&file_size,sizeof(long long));

			file_buf = malloc(file_size);

			read(fp,file_buf,file_size);
			write(fp1,file_buf,file_size);

			close(fp1);
			free(file_buf);

			a = read(fp,file_name,100);
		}
		close(fp);

	}else if(strcmp(argv[1],"-e")==0){
		if(argc!=4){
			printf("Failed to complete extraction operation");
			exit(-1);
		}

		int tarfp = open(argv[2], O_RDONLY);
		if(tarfp==-1) {
			printf("Failed to complete extraction operation");
			exit(-1);
		}

		for(int i =0;i<strlen(argv[2]);i++){
			if(argv[2][strlen(argv[2])-1-i]=='/') {
				argv[2][strlen(argv[2])-1-i] = '\0';
				break;
			}
		}
		if(chdir(argv[2])==-1){
			printf("Failed to complete extraction operation");
			exit(-1);
		}
		
		struct stat status = {0};
		if(stat("IndividualDump", &status)==-1) 
			mkdir("IndividualDump",0777);
		
		lseek(tarfp,sizeof(long long)+sizeof(int),SEEK_CUR);
		char *buf = malloc(sizeof(char)*100);
		unsigned long long int file_size = 0;
		int a = read(tarfp,buf,100);

		while(a!=0){
			a = read(tarfp,&file_size,sizeof(long long));

			if(strcmp(buf,argv[3])==0){
				sprintf(buf,"IndividualDump/%s",argv[3]);
				int fp = open(buf,O_RDWR | O_CREAT,0644);
				if(fp<0) {
					printf("Failed to complete extraction operation");
					exit(-1);
				}

				char *file_buf = malloc(file_size);

				a = read(tarfp,file_buf,file_size);
				write(fp,file_buf,file_size);
				free(file_buf);

				close(fp);
				break;
			}

			lseek(tarfp,file_size,SEEK_CUR);
			a = read(tarfp,buf,100);
		}
		close(tarfp);

	}else if(strcmp(argv[1],"-l")==0){
		if(argc!=3){
			printf("Failed to complete list operation");
			exit(-1);
		}

		int fp = open(argv[2],O_RDONLY);
		if(fp<0){
			printf("Failed to complete list operation");
			exit(-1);
		}

		for(int i =0;i<strlen(argv[2]);i++){
			if(argv[2][strlen(argv[2])-1-i]=='/') {
				argv[2][strlen(argv[2])-1-i] = '\0';
				break;
			}
		}
		
		char *file_path = malloc(strlen(argv[2])+15);
		char *buf = malloc(150);

		sprintf(file_path,"%s/tarStructure",argv[2]);
		int fp1 = open(file_path,O_RDWR | O_CREAT,0644);
		if(fp1<0){
			printf("Failed to complete list operation");
			exit(-1);
		}

		unsigned long long int file_size = 0;
		int total_files = 0;
		char *file_name = malloc(sizeof(char)*100);
		
		int a = read(fp,&file_size,sizeof(long long int));
		a = read(fp,&total_files,sizeof(int));
		sprintf(buf,"%llu\n%d\n",file_size,total_files);
		write(fp1,buf,strlen(buf));

		for(int i = 0;i<total_files;i++){
			a = read(fp,file_name,100);
			a = read(fp,&file_size,sizeof(long long));
			sprintf(buf,"%s %llu\n",file_name,file_size);
			write(fp1,buf,strlen(buf));
			lseek(fp,file_size,SEEK_CUR);
		}
		free(file_name);
		close(fp);
		close(fp1);
	}
	

	return 0;
}
