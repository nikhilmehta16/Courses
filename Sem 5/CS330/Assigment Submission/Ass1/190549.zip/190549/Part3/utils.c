#include "wc.h"

extern struct team teams[NUM_TEAMS];
extern int test;
extern int finalTeam1;
extern int finalTeam2;

int processType = HOST;
const char *team_names[] = {
    "India", "Australia", "New Zealand", "Sri Lanka",   // Group A
    "Pakistan", "South Africa", "England", "Bangladesh" // Group B
};

void teamPlay(void)
{
  char *a = malloc(sizeof(char));
  char *b = malloc(sizeof(char));
  char *buf = malloc(100);
  
  sprintf(buf, "test/%d/inp/%s", test, teams[processType].name);
  int fp = open(buf, O_RDONLY);
  if(fp<0){
    perror("Test File Unavailable");
    exit(-1);
  }

  read(teams[processType].commpipe[0], a, sizeof(char));

  while (strcmp(a,"0")!=0)
  {
    read(fp, b, sizeof(char));
    write(teams[processType].matchpipe[1], b, sizeof(char));
    read(teams[processType].commpipe[0], a, sizeof(char));
  }

  free(buf);
  close(fp);
  exit(0);
}

void endTeam(int teamID)
{
  write(teams[teamID].commpipe[1],"0",sizeof(char));
}

int match(int team1, int team2)
{
  char a, b;
  write(teams[team1].commpipe[1], "1", sizeof(char));
  read(teams[team1].matchpipe[0], &a, sizeof(char));
  write(teams[team2].commpipe[1], "1", sizeof(char));
  read(teams[team2].matchpipe[0], &b, sizeof(char));

  int bat = (a+b-2*'0')%2!=0 ? team1 : team2;
  int ball = (bat == team1) ? team2 : team1;

  char *buf = malloc(sizeof(char)*(strlen(teams[team1].name)+strlen(teams[team2].name)+50));
  
  if(team1<=3 && team2>3) sprintf(buf,"test/%d/out/%sv%s-Final",test,teams[bat].name,teams[ball].name);
  else sprintf(buf,"test/%d/out/%sv%s",test,teams[bat].name,teams[ball].name);
  int ofp= open(buf,O_RDWR | O_CREAT,0644);
  if(ofp<0){
    perror("Output File Can't be created");
    exit(-1);
  }

  sprintf(buf,"Innings1: %s bats\n",teams[bat].name);
  write(ofp,buf,strlen(buf));

  int team1_score,t_score = 0,p_score = 0,batsman = 1,winner = -1;

  for(int i = 0;i<120;i++){

    write(teams[bat].commpipe[1], "1", sizeof(char));
    write(teams[ball].commpipe[1], "1", sizeof(char));
    read(teams[bat].matchpipe[0], &a, sizeof(char));
    read(teams[ball].matchpipe[0], &b, sizeof(char));

    if(a==b) {
      sprintf(buf,"%d:%d\n",batsman,p_score);
      batsman++;
      p_score = 0;
      write(ofp,buf,strlen(buf));
    }else {
      p_score+=a-'0';
      t_score+=a-'0';
    }
    if(batsman==11) break;
  }

  if(batsman!=11) {
      sprintf(buf,"%d:%d*\n",batsman,p_score);
      write(ofp,buf,strlen(buf));
  }
  
  team1_score = t_score;
  t_score = 0;
  p_score = 0;
  batsman = 1;
  sprintf(buf,"%s TOTAL: %d\n",teams[bat].name,team1_score);
  write(ofp,buf,strlen(buf));

  int temp = bat;
  bat = ball;
  ball = temp;

  sprintf(buf,"Innings2: %s bats\n",teams[bat].name);
  write(ofp,buf,strlen(buf));
  
  
  for(int i = 0;i<120;i++){
    write(teams[bat].commpipe[1], "1", sizeof(char));
    write(teams[ball].commpipe[1], "1", sizeof(char));
    read(teams[bat].matchpipe[0], &a, sizeof(char));
    read(teams[ball].matchpipe[0], &b, sizeof(char));
    if(a==b) {
      sprintf(buf,"%d:%d\n",batsman,p_score);
      batsman++;
      p_score = 0;
      write(ofp,buf,strlen(buf));
    }else{
      p_score+=a-'0';
      t_score+=a-'0';
    }
    if(t_score>team1_score) {
      winner = bat;
      break;
    }else if(batsman == 11){
      if(t_score != team1_score) winner = ball;
      break;
    }
  }
  if(batsman!=11) {
      sprintf(buf,"%d:%d*\n",batsman,p_score);
      write(ofp,buf,strlen(buf));
  }

  sprintf(buf,"%s TOTAL: %d\n",teams[bat].name,t_score);
  write(ofp,buf,strlen(buf));
  
  if(winner == -1) {
    sprintf(buf,"TIE: %s beats %s\n",teams[team1].name,teams[team2].name);
    winner = team1;
    }
  else if(winner == ball) sprintf(buf,"%s beats %s by %d runs\n",teams[ball].name,teams[bat].name,team1_score-t_score);
  else sprintf(buf,"%s beats %s by %d wickets\n",teams[bat].name,teams[ball].name,11-batsman);
  // printf("%s\n",buf);

  write(ofp,buf,strlen(buf));
  close(ofp);
  return winner;
}

void spawnTeams(void)
{
  pid_t pid = 1;
  char buf[100];
  sprintf(buf,"test/%d/out",test);
  
  struct stat status = {0};
  if(stat(buf, &status)==-1) 
    mkdir(buf,0777);

  for (int i = 0; i < 8 && pid > 0; i++)
  {
    strcpy(teams[i].name, team_names[i]);
    pipe(teams[i].matchpipe);
    pipe(teams[i].commpipe);
    pid = fork();
    processType = i;
  }

  if (pid == 0)
  {
    teamPlay();
  }
  
}

void conductGroupMatches(void)
{
  int GP[2][2];
  pipe(GP[0]);
  pipe(GP[1]);
  pid_t child1, child2;

  child1 = fork();
  int process = 0, start_index = 0;
  int winner;
  if (child1 != 0)
  {
    child2 = fork();
    process = 1;
    start_index = 4;
  }
  if(child1==0 || child2==0) {
    int league_matches[6],match_number = 0;
    for (int i = 0; i < 4; i++)
    {
      for (int j = i + 1; j < 4; j++)
      {
        league_matches[match_number] = match(i + start_index, j + start_index);
        match_number++;
      }
    }
    int wins[4] = {0, 0, 0, 0};
    int max = 0;
    for (int i = 0; i < 6; i++)
    {
      winner = league_matches[i];
      wins[winner - start_index]++;
      max = wins[winner - start_index] > max ? wins[winner - start_index] : max;
    }
    
    winner = -1;
    for (int i = 0; i < 4; i++)
    {
      if (max == wins[i] && winner == -1)
      {
        winner = i + start_index;
        write(GP[process][1], &winner, sizeof(int));
      } else endTeam(i + start_index);
    }
    exit(0);
  }else{
    read(GP[0][0], &finalTeam1, sizeof(int));
    read(GP[1][0], &finalTeam2, sizeof(int));
    // printf("FT: %d FT:  %d\n",finalTeam1,finalTeam2);
  }
  
}
