#include <stdio.h>
#include <stdlib.h> 
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[])
{	
	unsigned long long int a = atoll(argv[argc-1]);
	a*=a;
	if(argc==2) printf("%llu",a);
	else{
		char *argv1[argc];
		
		argv1[argc-1] = NULL;
		argv1[argc-2] = malloc(sizeof(char)*65);
		argv1[0] = malloc(sizeof(char)*20);
		
		sprintf(argv1[argc-2], "%llu", a);
		strcpy(argv1[0],"./");
		strcat(argv1[0],argv[1]);

		for(int i = 2;i<argc-1;i++){
			argv1[i-1] = malloc(sizeof(char)*20);
			argv1[i-1] = argv[i];
		}
		
		if(execv(argv1[0],argv1))
            printf("UNABLE TO EXECUTE");
		exit(-1);
	}

	return 0;
}
