#include<ppipe.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>


// Per process information for the ppipe.
struct ppipe_info_per_process {

    // TODO:: Add members as per your need...
    int pid;
    int read_pos;
    int flag_read;
    int flag_write;

};

// Global information for the ppipe.
struct ppipe_info_global {

    char *ppipe_buff;       // Persistent pipe buffer: DO NOT MODIFY THIS.

    // TODO:: Add members as per your need...
    int pos_min_read;
    int pos_write;
    int used_buffer;
    int total_processes;

};

// Persistent pipe structure.
// NOTE: DO NOT MODIFY THIS STRUCTURE.
struct ppipe_info {

    struct ppipe_info_per_process ppipe_per_proc [MAX_PPIPE_PROC];
    struct ppipe_info_global ppipe_global;

};


// Function to allocate space for the ppipe and initialize its members.
struct ppipe_info* alloc_ppipe_info() {

    // Allocate space for ppipe structure and ppipe buffer.
    struct ppipe_info *ppipe = (struct ppipe_info*)os_page_alloc(OS_DS_REG);
    char* buffer = (char*) os_page_alloc(OS_DS_REG);

    // Assign ppipe buffer.
    ppipe->ppipe_global.ppipe_buff = buffer;

    ppipe->ppipe_global.pos_min_read = 0;
    ppipe->ppipe_global.pos_write = 0;
    ppipe->ppipe_global.used_buffer = 0;
    ppipe->ppipe_global.total_processes = 1;

    ppipe->ppipe_per_proc[0].flag_read = 1;
    ppipe->ppipe_per_proc[0].flag_write = 1;
    ppipe->ppipe_per_proc[0].read_pos = 0;
    ppipe->ppipe_per_proc[0].pid = get_current_ctx()->pid;

    // Return the ppipe.
    return ppipe;

}

// Function to free ppipe buffer and ppipe info object.
// NOTE: DO NOT MODIFY THIS FUNCTION.
void free_ppipe (struct file *filep) {

    os_page_free(OS_DS_REG, filep->ppipe->ppipe_global.ppipe_buff);
    os_page_free(OS_DS_REG, filep->ppipe);

} 

// Fork handler for ppipe.
int do_ppipe_fork (struct exec_context *child, struct file *filep) {
    
    /**
     *  TODO:: Implementation for fork handler
     *
     *  You may need to update some per process or global info for the ppipe.
     *  This handler will be called twice since ppipe has 2 file objects.
     *  Also consider the limit on no of processes a ppipe can have.
     *  Return 0 on success.
     *  Incase of any error return -EOTHERS.
     *
     */
    if(filep == NULL || child == NULL) return -EOTHERS;

    struct ppipe_info_per_process* ppipe_info_process;
    struct ppipe_info_global* info_global = &filep->ppipe->ppipe_global;

    if(info_global->total_processes==MAX_PPIPE_PROC) return -EOTHERS;
    u32 pp_number = -1;
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->ppipe->ppipe_per_proc[i].pid==child->ppid){
            info_global->total_processes++;
            pp_number = i;
        }
        if(filep->ppipe->ppipe_per_proc[i].pid == child->pid) return 0;
    }
    if(pp_number==-1) return -EOTHERS;

    filep->ppipe->ppipe_per_proc[info_global->total_processes-1]= filep->ppipe->ppipe_per_proc[pp_number];
    filep->ppipe->ppipe_per_proc[info_global->total_processes-1].pid = child->pid;
    // Return successfully.
    return 0;

}


// Function to close the ppipe ends and free the ppipe when necessary.
long ppipe_close (struct file *filep) {

    /**
     *  TODO:: Implementation of Pipe Close
     *
     *  Close the read or write end of the ppipe depending upon the file
     *      object's mode.
     *  You may need to update some per process or global info for the ppipe.
     *  Use free_pipe() function to free ppipe buffer and ppipe object,
     *      whenever applicable.
     *  After successful close, it return 0.
     *  Incase of any error return -EOTHERS.
     *                                                                          
     */

    int ret_value;

    if(filep == NULL || filep->type != PPIPE ) return -EOTHERS;

    
    struct ppipe_info_per_process* ppipe_info_process;
    struct ppipe_info_global* info_global = &filep->ppipe->ppipe_global;
    int process_number;
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->ppipe->ppipe_per_proc[i].pid == get_current_ctx()->pid){
            ppipe_info_process = &(filep->ppipe->ppipe_per_proc[i]);
            if(filep->mode == O_READ) ppipe_info_process->flag_read = 0;
            else if(filep->mode == O_WRITE) ppipe_info_process->flag_write = 0;
            process_number = i;
            break;            
        }
        
        if(i==(info_global->total_processes-1)) return -EOTHERS;
    }
    if(ppipe_info_process->flag_read==0 && ppipe_info_process->flag_write==0){
        info_global->total_processes--;
        for(int i = process_number;i<info_global->total_processes;i++) 
            filep->ppipe->ppipe_per_proc[i] = filep->ppipe->ppipe_per_proc[i+1];
        
    }

    
    if(info_global->total_processes==0) free_ppipe(filep);

    // Close the file.
    ret_value = file_close (filep);         // DO NOT MODIFY THIS LINE.

    // And return.
    return ret_value;

}

// Function to perform flush operation on ppipe.
int do_flush_ppipe (struct file *filep) {

    /**
     *  TODO:: Implementation of Flush system call
     *
     *  Reclaim the region of the persistent pipe which has been read by 
     *      all the processes.
     *  Return no of reclaimed bytes.
     *  In case of any error return -EOTHERS.
     *
     */

    if(filep == NULL && filep->type != PPIPE || filep->ppipe == NULL)
        return -EOTHERS;

    
    int reclaimed_bytes = 0;

    struct ppipe_info_per_process* ppipe_info_process;
    struct ppipe_info_global* info_global = &filep->ppipe->ppipe_global;

    int ppipe_reclaimable_bytes = 0;
    int min_read = info_global->pos_min_read;
    int max_reclaimable_bytes = MAX_PPIPE_SIZE;
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->ppipe->ppipe_per_proc[i].flag_read==0) continue;
        ppipe_reclaimable_bytes = (filep->ppipe->ppipe_per_proc[i].read_pos-min_read+MAX_PPIPE_SIZE)%MAX_PPIPE_SIZE;

        if(ppipe_reclaimable_bytes<max_reclaimable_bytes)
            max_reclaimable_bytes = ppipe_reclaimable_bytes;
    
    }
    reclaimed_bytes = max_reclaimable_bytes;
    info_global->pos_min_read = (info_global->pos_min_read+max_reclaimable_bytes)%MAX_PPIPE_SIZE;
    // Return reclaimed bytes.
    return reclaimed_bytes;

}

// Read handler for the ppipe.
int ppipe_read (struct file *filep, char *buff, u32 count) {
    
    /**
     *  TODO:: Implementation of PPipe Read
     *
     *  Read the data from ppipe buffer and write to the provided buffer.
     *  If count is greater than the present data size in the ppipe then just read
     *      that much data.
     *  Validate file object's access right.
     *  On successful read, return no of bytes read.
     *  Incase of Error return valid error code.
     *      -EACCES: In case access is not valid.
     *      -EINVAL: If read end is already closed.
     *      -EOTHERS: For any other errors.
     *
     */

    if(filep == NULL || buff == NULL)
        return -EOTHERS;

    if(filep->type != PPIPE || filep->mode != O_READ || filep->ppipe == NULL)
        return -EACCES;

    struct ppipe_info_per_process* ppipe_info_process;
    struct ppipe_info_global* info_global = &filep->ppipe->ppipe_global;

    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->ppipe->ppipe_per_proc[i].pid == get_current_ctx()->pid){
            ppipe_info_process = &(filep->ppipe->ppipe_per_proc[i]);
            break;
        }
        if(i==(info_global->total_processes-1)) return -EOTHERS;
    }



    int bytes_read = 0;

    while(bytes_read<count && ppipe_info_process->read_pos!=info_global->pos_write){
        bytes_read++;
        buff[bytes_read-1] = info_global->ppipe_buff[ppipe_info_process->read_pos];
        ppipe_info_process->read_pos++;
        ppipe_info_process->read_pos=(ppipe_info_process->read_pos)%4096;
    }

    // Return no of bytes read.
    return bytes_read;
	
}

// Write handler for ppipe.
int ppipe_write (struct file *filep, char *buff, u32 count) {

    /**
     *  TODO:: Implementation of PPipe Write
     *
     *  Write the data from the provided buffer to the ppipe buffer.
     *  If count is greater than available space in the ppipe then just write
     *      data that fits in that space.
     *  Validate file object's access right.
     *  On successful write, return no of written bytes.
     *  Incase of Error return valid error code.
     *      -EACCES: In case access is not valid.
     *      -EINVAL: If write end is already closed.
     *      -EOTHERS: For any other errors.
     *
     */
    if(filep == NULL || buff == NULL) return -EOTHERS;

    if(filep->type != PPIPE || filep->mode != O_WRITE || filep->ppipe == NULL) return -EACCES;

    struct ppipe_info_per_process* ppipe_info_process;
    struct ppipe_info_global* info_global = &filep->ppipe->ppipe_global;

    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->ppipe->ppipe_per_proc[i].pid == get_current_ctx()->pid){
            ppipe_info_process = &(filep->ppipe->ppipe_per_proc[i]);
            break;
        }
        if(i==(info_global->total_processes-1)) return -EOTHERS;
    }

    if(ppipe_info_process->flag_write == 0) return -EINVAL;

    int bytes_written = 0;
    int available_buff = MAX_PPIPE_SIZE-info_global->used_buffer;

    while(bytes_written<count && available_buff>0){
        bytes_written++;
        info_global->ppipe_buff[info_global->pos_write] = buff[bytes_written-1];
        info_global->pos_write++;
        info_global->pos_write=(info_global->pos_write)%4096;
        info_global->used_buffer++;
        available_buff--;
    }

    // Return no of bytes written.
    return bytes_written;

}

// Function to create persistent pipe.
int create_persistent_pipe (struct exec_context *current, int *fd) {

    /**
     *  TODO:: Implementation of PPipe Create
     *
     *  Find two free file descriptors.
     *  Create two file objects for both ends by invoking the alloc_file() function.
     *  Create ppipe_info object by invoking the alloc_ppipe_info() function and
     *      fill per process and global info fields.
     *  Fill the fields for those file objects like type, fops, etc.
     *  Fill the valid file descriptor in *fd param.
     *  On success, return 0.
     *  Incase of Error return valid Error code.
     *      -ENOMEM: If memory is not enough.
     *      -EOTHERS: Some other errors.
     *
     */
    if(current == NULL || fd == NULL) return -EOTHERS;

    struct file* FO1= alloc_file();
    struct file* FO2 = alloc_file();

    struct ppipe_info* ppipe_info_start = alloc_ppipe_info();

    FO1->type = PPIPE;
    FO1->mode = O_READ;
    FO1->inode = NULL;
    FO1->fops->read = ppipe_read;
    FO1->fops->close = ppipe_close;
    FO1->ppipe = ppipe_info_start;

    FO2->type = PPIPE;
    FO2->mode = O_WRITE;
    FO2->inode = NULL;
    FO2->fops->write = ppipe_write;
    FO2->fops->close = ppipe_close;
    FO2->ppipe = ppipe_info_start;

    int FO1_flag = 0;

    for(int i = 0;i<=MAX_OPEN_FILES;i++){
        if(current->files[i]==NULL){
            if(FO1_flag==0) {
                fd[0] = i;
                current->files[i] = FO1;
                FO1_flag = 1;
            }else{
                fd[1] = i;
                current->files[i] = FO2;
                break;
            }
        }
        if(i==MAX_OPEN_FILES) return -ENOMEM;
    }

    // Simple return.
    return 0;

}
