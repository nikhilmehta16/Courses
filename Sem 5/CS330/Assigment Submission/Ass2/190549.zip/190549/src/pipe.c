#include<pipe.h>
#include<context.h>
#include<memory.h>
#include<lib.h>
#include<entry.h>
#include<file.h>


// Per process info for the pipe.
struct pipe_info_per_process {

    // TODO:: Add members as per your need...
    int pid;
    int flag_read;
    int flag_write;

};

// Global information for the pipe.
struct pipe_info_global {

    char *pipe_buff;    // Pipe buffer: DO NOT MODIFY THIS.

    int pos_read;
    int pos_write;
    int used_buffer;
    int total_processes;


};

// Pipe information structure.
// NOTE: DO NOT MODIFY THIS STRUCTURE.
struct pipe_info {

    struct pipe_info_per_process pipe_per_proc [MAX_PIPE_PROC];
    struct pipe_info_global pipe_global;

};


// Function to allocate space for the pipe and initialize its members.
struct pipe_info* alloc_pipe_info () {
	
    // Allocate space for pipe structure and pipe buffer.
    struct pipe_info *pipe = (struct pipe_info*)os_page_alloc(OS_DS_REG);
    char* buffer = (char*) os_page_alloc(OS_DS_REG);

    // Assign pipe buffer.
    pipe->pipe_global.pipe_buff = buffer;

    pipe->pipe_global.pos_read = 0;
    pipe->pipe_global.pos_write = 0;
    pipe->pipe_global.used_buffer = 0;
    pipe->pipe_global.total_processes = 1;

    pipe->pipe_per_proc[0].flag_read = 1;
    pipe->pipe_per_proc[0].flag_write = 1;
    pipe->pipe_per_proc[0].pid = get_current_ctx()->pid;

    return pipe;

}

// Function to free pipe buffer and pipe info object.
// NOTE: DO NOT MODIFY THIS FUNCTION.
void free_pipe (struct file *filep) {

    os_page_free(OS_DS_REG, filep->pipe->pipe_global.pipe_buff);
    os_page_free(OS_DS_REG, filep->pipe);

}

// Fork handler for the pipe.
int do_pipe_fork (struct exec_context *child, struct file *filep) {

    /**
     *  TODO:: Implementation for fork handler
     *
     *  You may need to update some per process or global info for the pipe.
     *  This handler will be called twice since pipe has 2 file objects.
     *  Also consider the limit on no of processes a pipe can have.
     *  Return 0 on success.
     *  Incase of any error return -EOTHERS.
     *
     */
    if(filep == NULL || child == NULL) return -EOTHERS;

    struct pipe_info_per_process* pipe_info_process;
    struct pipe_info_global* info_global = &filep->pipe->pipe_global;

    if(info_global->total_processes == MAX_PIPE_PROC) return -EOTHERS;
    u32 pp_number = -1;
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->pipe->pipe_per_proc[i].pid==child->ppid){
            info_global->total_processes++;
            pp_number = i;
        }
        if(filep->pipe->pipe_per_proc[i].pid == child->pid) return 0;
    }

    if(pp_number==-1) return -EOTHERS;

    filep->pipe->pipe_per_proc[info_global->total_processes-1].flag_read = filep->pipe->pipe_per_proc[pp_number].flag_read;
    filep->pipe->pipe_per_proc[info_global->total_processes-1].flag_write = filep->pipe->pipe_per_proc[pp_number].flag_write;
    filep->pipe->pipe_per_proc[info_global->total_processes-1].pid = child->pid;

    // Return successfully.
    return 0;

}

// Function to close the pipe ends and free the pipe when necessary.
long pipe_close (struct file *filep) {

    /**
     *  TODO:: Implementation of Pipe Close
     *
     *  Close the read or write end of the pipe depending upon the file
     *      object's mode.
     *  You may need to update some per process or global info for the pipe.
     *  Use free_pipe() function to free pipe buffer and pipe object,
     *      whenever applicable.
     *  After successful close, it return 0.
     *  Incase of any error return -EOTHERS.
     *
     */

    int ret_value;
    if(filep == NULL || filep->type != PIPE ) return -EOTHERS;

    
    struct pipe_info_per_process* pipe_info_process;
    struct pipe_info_global* info_global = &filep->pipe->pipe_global;
    int process_number;
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->pipe->pipe_per_proc[i].pid == get_current_ctx()->pid){
            pipe_info_process = &(filep->pipe->pipe_per_proc[i]);
            if(filep->mode == O_READ) pipe_info_process->flag_read = 0;
            else if(filep->mode == O_WRITE) pipe_info_process->flag_write = 0;
            process_number = i;
            break;            
        }
        
        if(i==(info_global->total_processes-1)) return -EOTHERS;
    }
    if(pipe_info_process->flag_read==0 && pipe_info_process->flag_write==0){
        info_global->total_processes--;
        for(int i = process_number;i<info_global->total_processes;i++) 
            filep->pipe->pipe_per_proc[i] = filep->pipe->pipe_per_proc[i+1];
        
    }

    
    if(info_global->total_processes==0) free_pipe(filep);

    // Close the file and return.
    ret_value = file_close (filep);         // DO NOT MODIFY THIS LINE.

    // And return.
    return ret_value;

}

// Check whether passed buffer is valid memory location for read or write.
int is_valid_mem_range (unsigned long buff, u32 count, int access_bit) {

    /**
     *  TODO:: Implementation for buffer memory range checking
     *
     *  Check whether passed memory range is suitable for read or write.
     *  If access_bit == 1, then it is asking to check read permission.
     *  If access_bit == 2, then it is asking to check write permission.
     *  If range is valid then return 1.
     *  Incase range is not valid or have some permission issue return -EBADMEM.
     *
     */

    int ret_value = -EBADMEM;
    struct mm_segment *mm_seg = get_current_ctx()->mms; 
    struct vm_area *vm_ar = get_current_ctx()->vm_area;
    for(;vm_ar!=NULL;vm_ar = vm_ar->vm_next)
        if((buff >= vm_ar->vm_start) && (buff+count <= vm_ar->vm_end) && (vm_ar->access_flags & access_bit == access_bit))
            ret_value = 1;
    
    for(int i = 0;i<MAX_MM_SEGS;i++)
        if((buff >= mm_seg[i].start) && (buff+(unsigned long)count <= mm_seg[i].end) && (mm_seg[i].access_flags & access_bit== access_bit))
            ret_value = 1;
    // Return the finding.
    return ret_value;

}

// Function to read given no of bytes from the pipe.
int pipe_read (struct file *filep, char *buff, u32 count) {

    /**
     *  TODO:: Implementation of Pipe Read
     *
     *  Read the data from pipe buffer and write to the provided buffer.
     *  If count is greater than the present data size in the pipe then just read
     *       that much data.
     *  Validate file object's access right.
     *  On successful read, return no of bytes read.
     *  Incase of Error return valid error code.
     *       -EACCES: In case access is not valid.
     *       -EINVAL: If read end is already closed.
     *       -EOTHERS: For any other errors.
     *
     */


    if(filep == NULL || buff == NULL)
        return -EOTHERS;

    if(filep->type != PIPE || filep->mode != O_READ || filep->pipe == NULL || is_valid_mem_range((unsigned long)buff, count, 1) == -EBADMEM)
        return -EACCES;
    

    struct pipe_info_per_process* pipe_info_process;
    struct pipe_info_global* info_global = &filep->pipe->pipe_global;
    
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->pipe->pipe_per_proc[i].pid == get_current_ctx()->pid){
            pipe_info_process = &(filep->pipe->pipe_per_proc[i]);
            break;
        }
        if(i==(info_global->total_processes-1)) return -EACCES;
    }

    if(pipe_info_process->flag_read == 0) return -EINVAL;


    int bytes_read = 0;
    while(bytes_read<count && (info_global->used_buffer>0)){
        bytes_read++;
        buff[bytes_read-1] = info_global->pipe_buff[info_global->pos_read];
        info_global->pos_read++;
        info_global->pos_read=(info_global->pos_read)%MAX_PIPE_SIZE;
        info_global->used_buffer--;
    }

    // Return no of bytes read.
    return bytes_read;

}

// Function to write given no of bytes to the pipe.
int pipe_write (struct file *filep, char *buff, u32 count) {

    /**
     *  TODO:: Implementation of Pipe Write
     *
     *  Write the data from the provided buffer to the pipe buffer.
     *  If count is greater than available space in the pipe then just write data
     *       that fits in that space.
     *  Validate file object's access right.
     *  On successful write, return no of written bytes.
     *  Incase of Error return valid error code.
     *       -EACCES: In case access is not valid.
     *       -EINVAL: If write end is already closed.
     *       -EOTHERS: For any other errors.
     *
     */

    if(filep == NULL || buff == NULL) return -EOTHERS;

    if(filep->type != PIPE || filep->mode != O_WRITE || filep->pipe == NULL || is_valid_mem_range((unsigned long)buff, count, 2) == -EBADMEM) return -EACCES;
    
    struct pipe_info_per_process* pipe_info_process;
    struct pipe_info_global* info_global = &filep->pipe->pipe_global;
    
    for(int i = 0;i<info_global->total_processes;i++){
        if(filep->pipe->pipe_per_proc[i].pid == get_current_ctx()->pid){
            pipe_info_process = &(filep->pipe->pipe_per_proc[i]);
            break;
        }
        if(i==(info_global->total_processes-1)) return -EOTHERS;
    }

    if(pipe_info_process->flag_write == 0) return -EINVAL;

    int bytes_written = 0;
    int available_buff = MAX_PIPE_SIZE-info_global->used_buffer;

    while(bytes_written<count && available_buff>0){
        bytes_written++;
        info_global->pipe_buff[info_global->pos_write] = buff[bytes_written-1];
        info_global->pos_write++;
        info_global->pos_write=(info_global->pos_write)%MAX_PIPE_SIZE;
        info_global->used_buffer++;
        available_buff--;
    }

    // Return no of bytes written.
    return bytes_written;

}

// Function to create pipe.
int create_pipe (struct exec_context *current, int *fd) {

    if(current == NULL || fd == NULL) return -EOTHERS;

    struct file* FO1= alloc_file();
    struct file* FO2 = alloc_file();

    struct pipe_info* pipe_info_start = alloc_pipe_info();

    FO1->type = PIPE;
    FO1->mode = O_READ;
    FO1->inode = NULL;
    FO1->fops->read = pipe_read;
    FO1->fops->close = pipe_close;
    FO1->pipe = pipe_info_start;

    FO2->type = PIPE;
    FO2->mode = O_WRITE;
    FO2->inode = NULL;
    FO2->fops->write = pipe_write;
    FO2->fops->close = pipe_close;
    FO2->pipe = pipe_info_start;

    int FO1_flag = 0;
    for(int i = 0;i<=MAX_OPEN_FILES;i++){
        if(current->files[i]==NULL){
            if(FO1_flag==0) {
                fd[0] = i;
                current->files[i] = FO1;
                FO1_flag = 1;
            }else{
                fd[1] = i;
                current->files[i] = FO2;
                break;
            }
        }
        if(i==MAX_OPEN_FILES) return -ENOMEM;
    }
    
    return 0;

}
