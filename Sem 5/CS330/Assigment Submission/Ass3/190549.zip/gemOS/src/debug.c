#include <debug.h>
#include <context.h>
#include <entry.h>
#include <lib.h>
#include <memory.h>


/*****************************HELPERS******************************************/

/*
 * allocate the struct which contains information about debugger
 *
 */
struct debug_info *alloc_debug_info()
{
	struct debug_info *info = (struct debug_info *) os_alloc(sizeof(struct debug_info));
	if(info)
		bzero((char *)info, sizeof(struct debug_info));
	return info;
}
/*
 * frees a debug_info struct
 */
void free_debug_info(struct debug_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct debug_info));
}



/*
 * allocates a page to store registers structure
 */
struct registers *alloc_regs()
{
	struct registers *info = (struct registers*) os_alloc(sizeof(struct registers));
	if(info)
		bzero((char *)info, sizeof(struct registers));
	return info;
}

/*
 * frees an allocated registers struct
 */
void free_regs(struct registers *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct registers));
}

/*
 * allocate a node for breakpoint list
 * which contains information about breakpoint
 */
struct breakpoint_info *alloc_breakpoint_info()
{
	struct breakpoint_info *info = (struct breakpoint_info *)os_alloc(
		sizeof(struct breakpoint_info));
	if(info)
		bzero((char *)info, sizeof(struct breakpoint_info));
	return info;
}

/*
 * frees a node of breakpoint list
 */
void free_breakpoint_info(struct breakpoint_info *ptr)
{
	if(ptr)
		os_free((void *)ptr, sizeof(struct breakpoint_info));
}

/*
 * Fork handler.
 * The child context doesnt need the debug info
 * Set it to NULL
 * The child must go to sleep( ie move to WAIT state)
 * It will be made ready when the debugger calls wait
 */
void debugger_on_fork(struct exec_context *child_ctx)
{
	// printk("DEBUGGER FORK HANDLER CALLED\n");
	child_ctx->dbg = NULL;
	child_ctx->state = WAITING;
}


/******************************************************************************/


/* This is the int 0x3 handler
 * Hit from the childs context
 */

long int3_handler(struct exec_context *ctx)
{
	// printk("Int3 handler started\n");
	if(ctx==NULL || ctx->dbg != NULL) return -1;
	
	struct exec_context *p_ctx = get_ctx_by_pid(ctx->ppid);
	if(p_ctx == NULL) return -1;

	u64 current_add = ctx->regs.entry_rip-1; //rip is at beginning of next instruciton
	
	//control to end_handler
	if(current_add == (u64)p_ctx->dbg->end_handler){
		// printk("Int3 handler First IF started\n");
        p_ctx->dbg->running_bp_count = p_ctx->dbg->running_bp_count-1;
		
	}else{
		// printk("Int3 handler Else started\n");
		struct breakpoint_info *current_bp = p_ctx->dbg->head;
	
		while(current_bp != NULL){
			if(current_bp->addr == current_add) break;
			current_bp = current_bp->next;
		}
		if(current_bp == NULL) return -1;
		else{
			if(current_bp->end_breakpoint_enable==1){
				ctx->regs.entry_rsp = ctx->regs.entry_rsp - 8;
				*((u64*)(ctx->regs.entry_rsp)) = (u64)(p_ctx->dbg->end_handler);

				// u64* curr_running_bp = p_ctx->dbg->running_bp;	
				(p_ctx->dbg->running_bp)[p_ctx->dbg->running_bp_count] = current_add;
				p_ctx->dbg->running_bp_count = p_ctx->dbg->running_bp_count + 1;
			}
			
		}
	}
	// printk("Int3 handler if Else Ended\n");
	
	ctx->regs.entry_rsp -= 8;
	*((u64 *)(ctx->regs.entry_rsp)) = ctx->regs.rbp;
	u64 curr_add, rbp_reg;
	if(current_add == (u64)p_ctx->dbg->end_handler){
		 rbp_reg = ctx->regs.entry_rsp;
		 curr_add= (*(u64 *)(rbp_reg + 8));
	}else{

		 curr_add = ctx->regs.entry_rip-1;
		 rbp_reg =  ctx->regs.entry_rsp;
	}
	
	int pos = 0;
	while(curr_add!=END_ADDR){
		// printk("In for loop d\n");
		p_ctx->dbg->backtrace[pos] = curr_add;
		if(((u64)(rbp_reg+8))==(u64)(p_ctx->dbg->end_handler)) 
			curr_add = *((u64*)(rbp_reg+16)); 			
		else
			curr_add = *((u64*)(rbp_reg+8));	
		rbp_reg = *((u64*)(rbp_reg));
		pos = pos+1;
	}
	p_ctx->dbg->backtrace_count = pos;	
	
	p_ctx->state = READY;
	ctx->state = WAITING;
	// printk("Int3 handler Prcoess scheduled\n");
	schedule(p_ctx);
	return 0;
}

/*
 * Exit handler.
 * Deallocate the debug_info struct if its a debugger.
 * Wake up the debugger if its a child
 */
void debugger_on_exit(struct exec_context *ctx)
{
	if (ctx -> dbg!=NULL) {
		struct breakpoint_info* next;
		struct breakpoint_info* current = ctx -> dbg -> head;
		while (current!=NULL) {
			next = current->next;
			free_breakpoint_info(current);
			current = next;
		}
		free_debug_info(ctx -> dbg);	
	}
	else {
		struct exec_context* pctx = get_ctx_by_pid(ctx -> ppid);
		pctx -> dbg -> child_exit_flag = 1;
		pctx -> state = READY;
	}
}


/*
 * called from debuggers context
 * initializes debugger state
 */
int do_become_debugger(struct exec_context *ctx, void *addr)
{
	if(ctx==NULL) return -1;

	ctx->dbg = alloc_debug_info();
	if(ctx->dbg==NULL) return -1;

	ctx->dbg->breakpoint_count = 0;
	ctx->dbg->end_handler = addr;
	ctx->dbg->head = NULL;
	ctx->dbg->child_exit_flag = 0;
	ctx->dbg->backtrace_count = 0;

	

	*(u8*)addr = INT3_OPCODE;

	return 0;
}

/*
 * called from debuggers context
 */
int do_set_breakpoint(struct exec_context *ctx, void *addr, int flag)
{
	if(ctx == NULL || ctx->dbg == NULL || ctx->dbg->breakpoint_count == MAX_BREAKPOINTS) return -1;

	struct breakpoint_info* old_bps = ctx->dbg->head;	
	while(old_bps!=NULL){
		//already a breakpoint
		//=====Handle======
		if(old_bps->addr == (u64)addr) {
			old_bps->end_breakpoint_enable = flag;
			return 0;
			}
		old_bps = old_bps->next;
	}
	struct breakpoint_info* current = ctx->dbg->head;
	while(current!=NULL && current->next!=NULL) current = current->next;


	struct breakpoint_info* bp_info = alloc_breakpoint_info();
	*(u8*)addr = INT3_OPCODE;
	bp_info->addr = (u64)addr;
	bp_info->end_breakpoint_enable = flag;
	ctx->dbg->breakpoint_number = ctx->dbg->breakpoint_number+1;
	bp_info->num = ctx->dbg->breakpoint_number;
	ctx->dbg->breakpoint_count = ctx->dbg->breakpoint_count+1;

	if(current == NULL) ctx->dbg->head = bp_info;
	else current->next = bp_info;
	// printk("set_br testing=======\n");	
	return 0;
}

/*
 * called from debuggers context
 */
int do_remove_breakpoint(struct exec_context *ctx, void *addr)
{
	if(ctx==NULL || ctx->dbg == NULL || *(u8*)addr != INT3_OPCODE) return -1;

	for(int i = 0;i<ctx->dbg->running_bp_count;i++) {
		if(ctx->dbg->running_bp[i]==(u64)addr) return -1;
	}
	
	struct breakpoint_info *head = ctx->dbg->head;
	struct breakpoint_info *prev = NULL;
	if(head==NULL) return -1;
	while(head->addr!=(u64)addr && head!=NULL) {
		prev = head;
		head = head->next;
		}
	if(head!=NULL && head->addr==(u64)addr){
		ctx->dbg->breakpoint_count -= 1;
		*(u8 *)addr = PUSHRBP_OPCODE;
		if(prev == NULL) ctx->dbg->head = head->next;
		else prev->next = head->next; 
		free_breakpoint_info(head);
		
		return 0;
	}


	return -1;
}


/*
 * called from debuggers context
 */

int do_info_breakpoints(struct exec_context *ctx, struct breakpoint *ubp)
{
	if(ctx == NULL || ctx->dbg==NULL) return -1;
	struct breakpoint_info *current = ctx->dbg->head;
	int pos = 0;
	while(current!=NULL){
		ubp[pos].addr = current->addr;
		ubp[pos].num = current->num;
		ubp[pos].end_breakpoint_enable = current->end_breakpoint_enable;
		current = current->next;
		pos++;
	}
	return pos;
}


/*
 * called from debuggers context
 */
int do_info_registers(struct exec_context *ctx, struct registers *regs)
{
	if(ctx == NULL || ctx->dbg==NULL) return -1;
	for(int i = 1;i<MAX_PROCESSES;i++){
		struct exec_context *c_ctx = get_ctx_by_pid(i);
		if(c_ctx!=NULL && c_ctx->ppid==ctx->pid){

			
			u64 cur_addr = c_ctx->regs.entry_rip - 1;	
			struct breakpoint_info *current_bp = ctx->dbg->head;
	
			while(current_bp != NULL){
				if(current_bp->addr == cur_addr){
					regs->entry_rsp = (c_ctx->regs).entry_rsp + 16;
					break;
				}
				current_bp = current_bp->next;
				if(current_bp==NULL)
					regs->entry_rsp = (c_ctx->regs).entry_rsp + 8;
			}

			regs->rdi = c_ctx->regs.rdi;
			regs->rsi = c_ctx->regs.rsi;
			regs->rbp = c_ctx->regs.rbp;
			regs->rax = c_ctx->regs.rax;
			regs->rbx = c_ctx->regs.rbx;
			regs->rcx = c_ctx->regs.rcx;
			regs->rdx = c_ctx->regs.rdx;

			regs->entry_cs = c_ctx->regs.entry_cs;
			regs->entry_rflags = c_ctx->regs.entry_rflags;
			regs->entry_rip = c_ctx->regs.entry_rip -1;
			regs->entry_ss = c_ctx->regs.entry_ss;

			regs->r8 = c_ctx->regs.r8;
			regs->r9 = c_ctx->regs.r9;
			regs->r10 = c_ctx->regs.r10;
			regs->r11 = c_ctx->regs.r11;
			regs->r12 = c_ctx->regs.r12;
			regs->r13 = c_ctx->regs.r13;
			regs->r14 = c_ctx->regs.r14;
			regs->r15 = c_ctx->regs.r15;	

			
			return 0;
		}
	}
	return -1;
}

/*
 * Called from debuggers context
 */
int do_backtrace(struct exec_context *ctx, u64 bt_buf)
{
	if(ctx == NULL || ctx->dbg==NULL) return -1;
	for(int i = 0;i<ctx->dbg->backtrace_count;i++) 
		((u64 *)bt_buf)[i] = ctx->dbg->backtrace[i];


	return ctx->dbg->backtrace_count;
}

/*
 * When the debugger calls wait
 * it must move to WAITING state
 * and its child must move to READY state
 */

s64 do_wait_and_continue(struct exec_context *ctx)
{
	if(ctx == NULL || ctx->dbg==NULL) return -1;
	if(ctx->dbg->child_exit_flag){
		return CHILD_EXIT;
	}

	struct exec_context *c_ctx;
	for(int i = 1; i < MAX_PROCESSES; i++) {
		c_ctx = get_ctx_by_pid(i);
		if(c_ctx!=NULL && c_ctx->ppid==ctx->pid) {
			ctx->state = WAITING;
			c_ctx->state = READY;
			// printk("Test WC\n");
			schedule(c_ctx);
		}
	}

	return -1;
}






